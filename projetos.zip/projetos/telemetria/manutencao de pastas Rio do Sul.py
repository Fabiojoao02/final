# Databricks notebook source
# Caminho do diretório que você deseja esvaziar
#diretorio_a_esvaziar = "dbfs:/FileStore/tables/projetos/riodosul/"
#diretorio_a_esvaziar = "dbfs:/FileStore/tables/projetos/riodosul/"
diretorio_a_esvaziar = "dbfs:/FileStore/tables/projetos/"
#dbfs:/FileStore/tables/fiep/Base_limites_casa_RH.csv
# Obtenha a lista de arquivos no diretório
arquivos = dbutils.fs.ls(diretorio_a_esvaziar)

# Exclua cada arquivo no diretório
for arquivo in arquivos:
    dbutils.fs.rm(arquivo.path, recurse=True)

# Agora você pode excluir o diretório vazio
dbutils.fs.rm(diretorio_a_esvaziar)

# COMMAND ----------

diretorio_a_esvaziar = "dbfs:/FileStore/tables/projetos/riodosul/"
dbutils.fs.rm(diretorio_a_esvaziar, recurse=True)

# COMMAND ----------

# MAGIC %fs rm -r /FileStore/tables/projetos/riodosul/

# COMMAND ----------

# DBTITLE 1,Criar diretorio
dbutils.fs.mkdirs("/FileStore/tables/projetos/riodosul/delta")



# COMMAND ----------

# MAGIC %sh
# MAGIC ls -l

# COMMAND ----------

