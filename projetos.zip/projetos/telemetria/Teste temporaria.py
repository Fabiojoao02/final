# Databricks notebook source
# MAGIC %sql
# MAGIC create table table1 (
# MAGIC   cli int,
# MAGIC   dt date,
# MAGIC   valor float
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC delete from table1;
# MAGIC insert into table1 values (1,'2023-01-22',9);
# MAGIC insert into table1 values (2,'2023-01-10',22);
# MAGIC insert into table1 values (3,'2023-01-15',10);
# MAGIC insert into table1 values (1,'2023-01-30',6);

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from table1

# COMMAND ----------

# MAGIC %sql
# MAGIC select cli, max(valor) from table1
# MAGIC group by cli

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE or REPLACE TEMPORARY VIEW temp_table
# MAGIC AS
# MAGIC select cli, max(valor) valor, max(dt) dt  from table1
# MAGIC group by cli;

# COMMAND ----------

# MAGIC %sql
# MAGIC with dt1 AS (
# MAGIC     select cli, max(valor) from table1
# MAGIC   group by cli
# MAGIC )
# MAGIC select t2.cli, max(t2.dt) dt from table1 t2
# MAGIC join dt1 t1 on 
# MAGIC t2.cli= t1.cli
# MAGIC group by t2.cli;

# COMMAND ----------

