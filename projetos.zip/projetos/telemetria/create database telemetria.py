# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE database IF NOT EXISTS telemetria;
# MAGIC use telemetria;
# MAGIC --show database

# COMMAND ----------

