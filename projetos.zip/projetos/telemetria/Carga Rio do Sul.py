# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC ## Overview
# MAGIC
# MAGIC This notebook will show you how to create and query a table or DataFrame that you uploaded to DBFS. [DBFS](https://docs.databricks.com/user-guide/dbfs-databricks-file-system.html) is a Databricks File System that allows you to store data for querying inside of Databricks. This notebook assumes that you have a file already inside of DBFS that you would like to read from.
# MAGIC
# MAGIC This notebook is written in **Python** so the default cell type is Python. However, you can use different languages by using the `%LANGUAGE` syntax. Python, Scala, SQL, and R are all supported.

# COMMAND ----------

# MAGIC %fs ls "/FileStore/tables/projetos/riodosul"
# MAGIC

# COMMAND ----------

from datetime import datetime
from pyspark.sql.functions import lit, current_timestamp
import os

# Obtém o valor único de current_timestamp() como um DataFrame
timestamp_df = spark.range(1).select(current_timestamp().alias("timestamp"))

# Extrai o valor do timestamp como string
data_update = timestamp_df.first().timestamp.strftime('%Y-%m-%d %H:%M:%S')
print(data_update)


completo = "/FileStore/tables/projetos/riodosul/"
print(completo)

try:
    # Verifique se a pasta existe no DBFS
    files = dbutils.fs.ls(completo)
    if files:
        print("1-A pasta existe no DBFS.")
        
        files = dbutils.fs.ls(completo)
        for file in files:
            print(f"Path: {file.path}, Name: {file.name}, IsFile: {file.isFile()}")


        file_paths = [f.path for f in files if f.isFile() and f.name.endswith(".csv")]
        print(f"Arquivos: {file_paths}")

        # Diretório para salvar os arquivos delta
        caminho_arquivo_delta = "dbfs:/FileStore/tables/projetos/riodosul/delta/"

        for caminho_arquivo in file_paths:
            nome_arquivo = os.path.splitext(os.path.basename(caminho_arquivo))[0]
            nome_delta = nome_arquivo + ".delta"
            caminho_completo = os.path.join(caminho_arquivo_delta, nome_delta)
            
            print(f"Processando arquivo: {caminho_arquivo}")
            print(f"Caminho completo para salvar: {caminho_completo}")

            df = spark.read.format("csv") \
                .option("header", "true") \
                .option("delimiter", ";") \
                .option("inferSchema", "true") \
                .option("encoding", "UTF-8") \
                .load(caminho_arquivo)

            # Adiciona a nova coluna com o tipo timestamp
            df_with_new_column = df.withColumn("data_update", lit(data_update))

            # Salva o DataFrame com a nova coluna em um novo arquivo Parquet
            df_with_new_column.write.parquet(caminho_completo, mode="append")

    else:
        print("6-A pasta não existe no DBFS.")
except Exception as e:
    print(f"Erro: {e}")



# COMMAND ----------

df_telemetria= spark.read.format("parquet").load("dbfs:/FileStore/tables/projetos/riodosul/delta/telemetriaRSUL.delta")
df_telemetria.createOrReplaceTempView("riodosul")



# COMMAND ----------

# MAGIC %sql
# MAGIC select * from riodosul limit 10

# COMMAND ----------

# MAGIC %sql
# MAGIC select nome_rio,nivel_rio ,vlr_nivel_rio, uni_nivel_rio,
# MAGIC     chuva_total chuva ,vlr_chuva,uni_chuva,
# MAGIC     temperatura
# MAGIC     ,cast(SUBSTRING_INDEX(vlr_temp,'º',1) as float) vlr_temp
# MAGIC     ,uni_temp,
# MAGIC     umidade,uni_umidade,vlr_umidade,
# MAGIC     pressao,vlr_pressao,uni_pressao,status
# MAGIC     ,vento,vlr_vento,uni_vento,direcao,leitura,
# MAGIC     SUBSTRING_INDEX(nome_rio, ' - ', 1) AS ponte,
# MAGIC     substring(SUBSTRING(nome_rio,1,len(nome_rio)-10) ,charindex(' - ',SUBSTRING(nome_rio,1,len(nome_rio)-10) )+2,len(SUBSTRING(nome_rio,1,len(nome_rio)-10) )-10) rio
# MAGIC     ,TRIM(right(nome_rio, 10)) AS cidade,
# MAGIC leitura,
# MAGIC TO_TIMESTAMP(
# MAGIC     CONCAT(
# MAGIC         REGEXP_EXTRACT(leitura, r'(\d{2}/\d{2}/\d{4})', 1), 
# MAGIC         ' ', 
# MAGIC         LPAD(REGEXP_EXTRACT(leitura, r'(\d{1,2}:\d{2})', 1), 5, '0')
# MAGIC     ),
# MAGIC     'dd/MM/yyyy HH:mm'
# MAGIC ) AS dt_hora
# MAGIC
# MAGIC from riodosul 
# MAGIC
# MAGIC
# MAGIC
# MAGIC