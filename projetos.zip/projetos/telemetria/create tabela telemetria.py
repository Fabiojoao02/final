# Databricks notebook source
# Caminho do diretório que você deseja esvaziar
diretorio_a_esvaziar = "dbfs:/user/hive/warehouse/telemetria.db/telemetria"

# Obtenha a lista de arquivos no diretório
arquivos = dbutils.fs.ls(diretorio_a_esvaziar)

# Exclua cada arquivo no diretório
for arquivo in arquivos:
    dbutils.fs.rm(arquivo.path, recurse=True)

# Agora você pode excluir o diretório vazio
dbutils.fs.rm(diretorio_a_esvaziar)

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE IF EXISTS telemetria.telemetria

# COMMAND ----------

# MAGIC %sql
# MAGIC --ALTER TABLE your_table_name
# MAGIC ---SET TBLPROPERTIES ('delta.columnMapping' = 'name');
# MAGIC --IF EXISTS
# MAGIC CREATE TABLE IF NOT EXISTS telemetria.telemetria (
# MAGIC   nome_rio string,
# MAGIC   nivel_rio string,
# MAGIC   vlr_nivel_rio integer,
# MAGIC   uni_nivel_rio string,
# MAGIC   chuva_total string,
# MAGIC   vlr_chuva double,
# MAGIC   uni_chuva string,
# MAGIC   temperatura string,
# MAGIC   vlr_temp string,
# MAGIC   uni_temp string,
# MAGIC   umidade string,
# MAGIC   uni_umidade string,
# MAGIC   pressao string,
# MAGIC   vlr_pressao double,
# MAGIC   uni_pressao string,
# MAGIC   status string,
# MAGIC   vento string,
# MAGIC   vlr_vento double,
# MAGIC   uni_vento string,
# MAGIC   direcao string,
# MAGIC   leitura string,
# MAGIC   vlr_umidade string,
# MAGIC   cidade string,
# MAGIC   rio string,
# MAGIC   ponte string,
# MAGIC   dt_hora TIMESTAMP,
# MAGIC   data_update TIMESTAMP
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from telemetria.telemetria 

# COMMAND ----------

