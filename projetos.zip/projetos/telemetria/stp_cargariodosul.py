# Databricks notebook source
# DBTITLE 1,Criando os dataframes
df_telemetria= spark.read.format("parquet").load("dbfs:/FileStore/tables/projetos/riodosul/delta/telemetriaRSUL.delta")
df_telemetria.createOrReplaceTempView("riodosul")


# COMMAND ----------

# MAGIC %sql
# MAGIC select * from riodosul

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC   nome_rio,
# MAGIC   nivel_rio,
# MAGIC   vlr_nivel_rio,
# MAGIC   uni_nivel_rio,
# MAGIC   chuva_total AS chuva,
# MAGIC   TRY_CAST(vlr_chuva AS FLOAT) AS vlr_chuva,
# MAGIC   uni_chuva,
# MAGIC   temperatura,
# MAGIC   TRY_CAST(SUBSTRING_INDEX(vlr_temp, 'º', 1) AS FLOAT) AS vlr_temp,
# MAGIC   uni_temp,
# MAGIC   umidade,
# MAGIC   uni_umidade,
# MAGIC   TRY_CAST(vlr_umidade AS FLOAT) AS vlr_umidade,
# MAGIC   pressao,
# MAGIC   TRY_CAST(vlr_pressao AS FLOAT) AS vlr_pressao,
# MAGIC   uni_pressao,
# MAGIC   status,
# MAGIC   vento,
# MAGIC   TRY_CAST(vlr_vento AS FLOAT) AS vlr_vento,
# MAGIC   uni_vento,
# MAGIC   direcao,
# MAGIC   leitura,
# MAGIC   TRIM(SUBSTRING_INDEX(nome_rio, ' - ', 1)) AS ponte,
# MAGIC   TRIM(SUBSTRING(
# MAGIC       nome_rio,
# MAGIC       CHARINDEX(' - ', nome_rio) + 3,
# MAGIC       LENGTH(nome_rio) - CHARINDEX(' - ', nome_rio) - 10
# MAGIC   )) AS rio,
# MAGIC   TRIM(RIGHT(nome_rio, 10)) AS cidade,
# MAGIC   TO_TIMESTAMP(
# MAGIC     CONCAT(
# MAGIC       REGEXP_EXTRACT(leitura, r'(\d{2}/\d{2}/\d{4})', 1), 
# MAGIC       ' ', 
# MAGIC       LPAD(REGEXP_EXTRACT(leitura, r'(\d{1,2}:\d{2})', 1), 5, '0')
# MAGIC     ),
# MAGIC     'dd/MM/yyyy HH:mm'
# MAGIC   ) AS dt_hora,
# MAGIC     EXTRACT(HOUR FROM TO_TIMESTAMP(
# MAGIC     CONCAT(
# MAGIC       REGEXP_EXTRACT(leitura, r'(\d{2}/\d{2}/\d{4})', 1), 
# MAGIC       ' ', 
# MAGIC       LPAD(REGEXP_EXTRACT(leitura, r'(\d{1,2}:\d{2})', 1), 5, '0')
# MAGIC     ),
# MAGIC     'dd/MM/yyyy HH:mm'
# MAGIC   )) AS hora,
# MAGIC   data_update
# MAGIC FROM
# MAGIC   riodosul;

# COMMAND ----------

# DBTITLE 1,Materializa tabela limite carga
# MAGIC %sql
# MAGIC DELETE FROM telemetria.telemetria;
# MAGIC
# MAGIC INSERT INTO telemetria.telemetria
# MAGIC (
# MAGIC   nome_rio,
# MAGIC   nivel_rio,
# MAGIC   vlr_nivel_rio,
# MAGIC   uni_nivel_rio,
# MAGIC   chuva_total,
# MAGIC   vlr_chuva,
# MAGIC   uni_chuva,
# MAGIC   temperatura,
# MAGIC   vlr_temp,
# MAGIC   uni_temp,
# MAGIC   umidade,
# MAGIC   uni_umidade,
# MAGIC   vlr_umidade,
# MAGIC   pressao,
# MAGIC   vlr_pressao,
# MAGIC   uni_pressao,
# MAGIC   status,
# MAGIC   vento,
# MAGIC   vlr_vento,
# MAGIC   uni_vento,
# MAGIC   direcao,
# MAGIC   leitura,
# MAGIC   ponte,
# MAGIC   rio,
# MAGIC   cidade,
# MAGIC   dt_hora,
# MAGIC   data_update
# MAGIC )
# MAGIC SELECT
# MAGIC   nome_rio,
# MAGIC   nivel_rio,
# MAGIC   vlr_nivel_rio,
# MAGIC   uni_nivel_rio,
# MAGIC   chuva_total AS chuva,
# MAGIC   TRY_CAST(vlr_chuva AS FLOAT) AS vlr_chuva,
# MAGIC   uni_chuva,
# MAGIC   temperatura,
# MAGIC   TRY_CAST(SUBSTRING_INDEX(vlr_temp, 'º', 1) AS FLOAT) AS vlr_temp,
# MAGIC   uni_temp,
# MAGIC   umidade,
# MAGIC   uni_umidade,
# MAGIC   TRY_CAST(vlr_umidade AS FLOAT) AS vlr_umidade,
# MAGIC   pressao,
# MAGIC   TRY_CAST(vlr_pressao AS FLOAT) AS vlr_pressao,
# MAGIC   uni_pressao,
# MAGIC   status,
# MAGIC   vento,
# MAGIC   TRY_CAST(vlr_vento AS FLOAT) AS vlr_vento,
# MAGIC   uni_vento,
# MAGIC   direcao,
# MAGIC   leitura,
# MAGIC   TRIM(SUBSTRING_INDEX(nome_rio, ' - ', 1)) AS ponte,
# MAGIC   TRIM(SUBSTRING(
# MAGIC       nome_rio,
# MAGIC       CHARINDEX(' - ', nome_rio) + 3,
# MAGIC       LENGTH(nome_rio) - CHARINDEX(' - ', nome_rio) - 10
# MAGIC   )) AS rio,
# MAGIC   TRIM(RIGHT(nome_rio, 10)) AS cidade,
# MAGIC   TO_TIMESTAMP(
# MAGIC     CONCAT(
# MAGIC       REGEXP_EXTRACT(leitura, r'(\d{2}/\d{2}/\d{4})', 1), 
# MAGIC       ' ', 
# MAGIC       LPAD(REGEXP_EXTRACT(leitura, r'(\d{1,2}:\d{2})', 1), 5, '0')
# MAGIC     ),
# MAGIC     'dd/MM/yyyy HH:mm'
# MAGIC   ) AS dt_hora,
# MAGIC   data_update
# MAGIC FROM
# MAGIC   riodosul;
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from telemetria.telemetria

# COMMAND ----------

