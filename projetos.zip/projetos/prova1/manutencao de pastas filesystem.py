# Databricks notebook source
# MAGIC %fs help

# COMMAND ----------



# COMMAND ----------

# Caminho do diretório que você deseja esvaziar
diretorio_a_esvaziar = "dbfs:/FileStore/data/"
#diretorio_a_esvaziar = "dbfs:/FileStore/tables/fiep/Base_limites_casa_RH.csv"
# Obtenha a lista de arquivos no diretório
arquivos = dbutils.fs.ls(diretorio_a_esvaziar)

# Exclua cada arquivo no diretório
for arquivo in arquivos:
    print(arquivo)
    dbutils.fs.rm(arquivo.path, recurse=True)

# Agora você pode excluir o diretório vazio
dbutils.fs.rm(diretorio_a_esvaziar)