# Databricks notebook source
# MAGIC %sql
# MAGIC select count(*)     from  gold.fat_saude  where 
# MAGIC --select *  from  gold.fat_saude where cd_id = 'urn:uuid:b98e4960-beeb-41a3-9400-3e07ece715d0'
# MAGIC --group by cd_id
# MAGIC --having count(*)>1
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC Quais são as 10 condições médicas mais comuns?
# MAGIC Contagem de entries onde o resource.resourceType é "Condition", agrupando pela condição (resource.code.text), ordenando do maior para o menor número de ocorrências, limitando a 10 resultados.

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(distinct cd_id), condicao     from  gold.fat_saude 
# MAGIC where
# MAGIC nm_recurso = 'Condition'
# MAGIC group by condicao

# COMMAND ----------

# MAGIC %md
# MAGIC Quais são os 10 medicamentos mais prescritos?
# MAGIC Contagem de entries onde o resource.resourceType é "MedicationRequest", agrupando pelo medicamento (resource.medicationCodeableConcept.text), ordenando do maior para o menor número de prescrições, limitando a 10 resultados.

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(distinct cd_id), medicamento    from  gold.fat_saude 
# MAGIC where
# MAGIC nm_recurso = 'MedicationRequest' --Patient'--'Condition'
# MAGIC group by medicamento

# COMMAND ----------

# MAGIC %md
# MAGIC Quantos pacientes são do sexo masculino?
# MAGIC Contagem de entries onde o resource.resourceType é "Patient" e o sexo (resource.gender) é "male".

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(distinct cd_id), nm_sexo    from  gold.fat_saude 
# MAGIC where
# MAGIC nm_recurso = 'Patient' and nm_sexo = 'male'
# MAGIC group by nm_sexo