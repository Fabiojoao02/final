# Databricks notebook source
# MAGIC %sql
# MAGIC --drop SCHEMA bronze

# COMMAND ----------

# MAGIC %sql
# MAGIC --ALTER TABLE your_table_name
# MAGIC ---SET TBLPROPERTIES ('delta.columnMapping' = 'name');
# MAGIC --IF EXISTS  
# MAGIC CREATE SCHEMA IF NOT EXISTS bronze;
# MAGIC CREATE SCHEMA IF NOT EXISTS silver;
# MAGIC -- USE bronze;
# MAGIC
# MAGIC -- CREATE TABLE IF NOT EXISTS bronze.origem (
# MAGIC --     fullUrl STRING,
# MAGIC --     request STRING,
# MAGIC --     resource STRING,
# MAGIC --     data_update TIMESTAMP
# MAGIC -- );
# MAGIC CREATE SCHEMA IF NOT EXISTS gold;
# MAGIC USE gold;
# MAGIC
# MAGIC -- CREATE TABLE IF NOT EXISTS gold.fat_saude (
# MAGIC -- cd_id STRING, --fullUrl
# MAGIC -- nm_recurso STRING,  --resourceType
# MAGIC -- nm_sexo STRING,  --gender
# MAGIC -- dt_nascimento date, --birthDate
# MAGIC -- status STRING, --status
# MAGIC -- condicao STRING, 
# MAGIC -- medicamento STRING,
# MAGIC -- nm_user STRING, --name_use
# MAGIC -- nm_sobrenome STRING, --family_name
# MAGIC -- nm_paciente STRING, --given_name
# MAGIC -- dh_ataulizacao timestamp
# MAGIC -- );
# MAGIC