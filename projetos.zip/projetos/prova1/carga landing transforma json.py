# Databricks notebook source
# DBTITLE 1,Lista arquivos .json
#display(dbutils.fs.ls("dbfs:/FileStore/data/"))

#df = spark.read.json("dbfs:/FileStore/data/")


# COMMAND ----------

# DBTITLE 1,lê os arquivos e inseri DataFrame
import json
from pyspark.sql import SparkSession

spark = SparkSession.builder.getOrCreate()

# Lista os arquivos no DBFS
files = dbutils.fs.ls("dbfs:/FileStore/data/")

# Lista para armazenar caminhos dos arquivos JSON
json_paths = [file.path for file in files if file.path.endswith(".json")]

# Se houver arquivos JSON, carregá-los no PySpark DataFrame
if json_paths:
    df = spark.read.option("multiLine", "true").json(json_paths)
   # df.show(truncate=False)
else:
    print("Nenhum arquivo JSON encontrado.")



# COMMAND ----------

# DBTITLE 1,cria schema
from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType, ArrayType, DoubleType, BooleanType

# Inicializar sessão Spark
spark = SparkSession.builder.appName("FHIR Schema").getOrCreate()

# Definir schemas individuais
resourceText_schema = StructType([
    StructField("status", StringType(), True),
    StructField("div", StringType(), True)
])

resourceExtensionInner_schema = StructType([
    StructField("url", StringType(), True),
    StructField("valueCoding", StructType([
        StructField("system", StringType(), True),
        StructField("code", StringType(), True),
        StructField("display", StringType(), True)
    ]), True),
    StructField("valueString", StringType(), True)
])

resourceExtension_schema = StructType([
    StructField("url", StringType(), True),
    StructField("valueString", StringType(), True),
    StructField("valueCode", StringType(), True),
    StructField("valueDecimal", DoubleType(), True),
    StructField("valueAddress", StructType([
        StructField("city", StringType(), True),
        StructField("state", StringType(), True),
        StructField("country", StringType(), True)
    ]), True),
    StructField("extension", ArrayType(resourceExtensionInner_schema), True)
])

resourceIdentifier_schema = StructType([
    StructField("system", StringType(), True),
    StructField("value", StringType(), True),
    StructField("type", StructType([
        StructField("coding", ArrayType(StructType([
            StructField("system", StringType(), True),
            StructField("code", StringType(), True),
            StructField("display", StringType(), True)
        ])), True),
        StructField("text", StringType(), True)
    ]), True)
])

resourceName_schema = ArrayType(StructType([
    StructField("use", StringType(), True),
    StructField("family", StringType(), True),
    StructField("given", ArrayType(StringType()), True),
    StructField("prefix", ArrayType(StringType()), True)
]))

resourceTelecom_schema = StructType([
    StructField("system", StringType(), True),
    StructField("value", StringType(), True),
    StructField("use", StringType(), True)
])

resourceAddressInner_schema = StructType([
    StructField("url", StringType(), True),
    StructField("extension", ArrayType(StructType([
        StructField("url", StringType(), True),
        StructField("valueDecimal", DoubleType(), True)
    ])), True)
])

resourceAddress_schema = StructType([
    StructField("line", ArrayType(StringType()), True),
    StructField("city", StringType(), True),
    StructField("state", StringType(), True),
    StructField("postalCode", StringType(), True),
    StructField("country", StringType(), True),
    StructField("extension", ArrayType(resourceAddressInner_schema), True)
])

resourceMaritalStatus_schema = StructType([
    StructField("coding", ArrayType(StructType([
        StructField("system", StringType(), True),
        StructField("code", StringType(), True),
        StructField("display", StringType(), True)
    ])), True),
    StructField("text", StringType(), True)
])

resourceCommunication_schema = StructType([
    StructField("language", StructType([
        StructField("coding", ArrayType(StructType([
            StructField("system", StringType(), True),
            StructField("code", StringType(), True),
            StructField("display", StringType(), True)
        ])), True),
        StructField("text", StringType(), True)
    ]), True)
])

resource_schema = StructType([
    StructField("resourceType", StringType(), True),
    StructField("id", StringType(), True),
    StructField("text", resourceText_schema, True),
    StructField("extension", ArrayType(resourceExtension_schema), True),
    StructField("identifier", ArrayType(resourceIdentifier_schema), True),
    StructField("name", ArrayType(resourceName_schema), True),
    StructField("telecom", ArrayType(resourceTelecom_schema), True),
    StructField("gender", StringType(), True),
    StructField("birthDate", StringType(), True),
    StructField("address", ArrayType(resourceAddress_schema), True),
    StructField("maritalStatus", resourceMaritalStatus_schema, True),
    StructField("multipleBirthBoolean", BooleanType(), True),
    StructField("communication", ArrayType(resourceCommunication_schema), True),
    StructField("status", StringType(), True),
    StructField("class", StructType([
        StructField("system", StringType(), True),
        StructField("code", StringType(), True)
    ]), True),
    StructField("type", ArrayType(StructType([
        StructField("coding", ArrayType(StructType([
            StructField("system", StringType(), True),
            StructField("code", StringType(), True),
            StructField("display", StringType(), True)
        ])), True),
        StructField("text", StringType(), True)
    ])), True),
    StructField("subject", StructType([
        StructField("reference", StringType(), True),
        StructField("display", StringType(), True)
    ]), True),
    StructField("participant", ArrayType(StructType([
        StructField("individual", StructType([
            StructField("reference", StringType(), True),
            StructField("display", StringType(), True)
        ]), True)
    ])), True),
    StructField("period", StructType([
        StructField("start", StringType(), True),
        StructField("end", StringType(), True)
    ]), True),
    StructField("serviceProvider", StructType([
        StructField("reference", StringType(), True),
        StructField("display", StringType(), True)
    ]), True),
    StructField("diagnosis", ArrayType(StructType([
        StructField("sequence", StringType(), True),
        StructField("diagnosisReference", StructType([
            StructField("reference", StringType(), True)
        ]), True)
    ])), True),
    StructField("total", StructType([
        StructField("value", DoubleType(), True),
        StructField("currency", StringType(), True)
    ]), True),
    StructField("insurance", ArrayType(StructType([
        StructField("sequence", StringType(), True),
        StructField("focal", BooleanType(), True),
        StructField("coverage", StructType([
            StructField("display", StringType(), True)
        ]), True)
    ])), True),
    StructField("careTeam", ArrayType(StructType([
        StructField("sequence", StringType(), True),
        StructField("provider", StructType([
            StructField("reference", StringType(), True)
        ]), True),
        StructField("role", StructType([
            StructField("coding", ArrayType(StructType([
                StructField("system", StringType(), True),
                StructField("code", StringType(), True),
                StructField("display", StringType(), True)
            ])), True)
        ]), True)
    ])), True)
])

entry_schema = StructType([
    StructField("fullUrl", StringType(), True),
    StructField("resource", resource_schema, True)
])

fhir_schema = StructType([
    StructField("resourceType", StringType(), True),
    StructField("type", StringType(), True),
    StructField("entry", ArrayType(entry_schema), True)
])



# COMMAND ----------


#df.write.mode("append").parquet("dbfs:/FileStore/data/output.parquet")

# COMMAND ----------

from pyspark.sql.functions import from_json, col,explode


# Explodir a coluna "entry" para obter "resource"
df_entry_exploded = df.withColumn("entry", explode(col("entry"))).select("entry.*")

# Converter "resource.name" de JSON String para um Array de Structs
df_parsed = df_entry_exploded.withColumn("resource_name_parsed", from_json(col("resource.name"), resourceName_schema))

# Explodir "resource_name_parsed" para acessar os campos
df_final = df_parsed.withColumn("name", explode(col("resource_name_parsed"))).select(
    col("fullUrl").alias("cd_id"),
    col("resource.resourceType").alias("nm_recurso"),
    col("resource.gender").alias("nm_sexo"),
    col("resource.birthDate").alias("dt_nascimento"),
    col("resource.status").alias("status"),
    col("resource.code.text").alias("condicao"),
    col("resource.medicationCodeableConcept.text").alias("medicamento"),
    
    col("name.use").alias("nm_user"),
    col("name.family").alias("nm_sobrenome"),
    explode(col("name.given")).alias("nm_paciente")  # Se "given" for um array, explodir
).distinct()

#display(df_final)

# COMMAND ----------

# DBTITLE 1,Delta-dim_providers
df_providers = df_entry_exploded.selectExpr(
    "resource.id as provider_id",
    "resource.careTeam[0].provider.reference as provider_ref"
).distinct()

#df_providers.write.mode("overwrite").saveAsTable("silver.dim_providers")
#df_providers.write.mode("append").saveAsTable("silver.dim_providers")
df_providers.write.format("delta").mode("overwrite").option("mergeSchema", "true").save("dbfs:/user/hive/warehouse/silver.db/dim_providers")

# COMMAND ----------

#df_providers.groupBy("provider_id").count().filter("count > 1").show()

# COMMAND ----------

#print(df_providers.select("provider_id").distinct().count())

# COMMAND ----------

#spark.sql("DESCRIBE HISTORY silver.dim_providers").show(truncate=False)

# COMMAND ----------

#print(df_providers.count())

# COMMAND ----------

#spark.sql("DROP TABLE IF EXISTS bronze.origem")

#dbutils.fs.rm("dbfs:/user/hive/warehouse/bronze.db/bronze.origem", True)

# COMMAND ----------

#df_providers.printSchema()

# COMMAND ----------

# DBTITLE 1,catalog - dim_providers
from delta.tables import DeltaTable
from pyspark.sql.utils import AnalysisException



table_name = "silver.dim_providers"

# Verifica se a tabela existe
table_exists = spark._jsparkSession.catalog().tableExists(table_name)

if table_exists:
    # Se a tabela já existe, faz o merge
    delta_table = DeltaTable.forName(spark, table_name)

    delta_table.alias("tgt").merge(
        df_providers.alias("src"),
        "tgt.provider_id = src.provider_id"
    ).whenNotMatchedInsertAll().execute()
    
    print("Tabela existente, realizando MERGE.")

else:
    # Se a tabela não existe, cria e insere os dados com APPEND
    spark.sql("CREATE TABLE IF NOT EXISTS silver.dim_providers USING DELTA LOCATION 'dbfs:/user/hive/warehouse/silver.db/dim_providers'")
    
    df_providers.write.format("delta").option("mergeSchema", "true").mode("append").saveAsTable(table_name)
    print("Tabela não encontrada, criando e inserindo dados com APPEND.")

# COMMAND ----------

# MAGIC %sql
# MAGIC --select * from silver.dim_providers

# COMMAND ----------

# DBTITLE 1,catalog-dim_providers

#spark.sql("CREATE TABLE IF NOT EXISTS silver.dim_providers USING DELTA LOCATION 'dbfs:/user/hive/warehouse/silver.db/dim_providers'")
#df_providers.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("silver.dim_providers")

# COMMAND ----------

# MAGIC %sql
# MAGIC --drop table silver.dim_providers
# MAGIC --select * from silver.dim_providers where provider_id='2e196a95-cf79-4ef7-b9ab-9fb74eaadbed'

# COMMAND ----------

# MAGIC %sql
# MAGIC -- select count(*), provider_id 
# MAGIC -- from silver.dim_providers
# MAGIC -- group by provider_id
# MAGIC -- having count(*)>1
# MAGIC --75838

# COMMAND ----------

# DBTITLE 1,Delta - fat_encounters
df_encounters = df_entry_exploded.selectExpr(
    "resource.id as encounter_id",
    "resource.subject.reference as patient_id",
    "resource.serviceProvider.reference as provider_id",
    "resource.period.start as start_time",
    "resource.period.end as end_time",
    "resource.status as status"
)

df_encounters.write.format("delta").mode("overwrite").save("dbfs:/user/hive/warehouse/silver.db/fat_encounters")

# COMMAND ----------

# DBTITLE 1,catalog - fat_encounters
spark.sql("CREATE TABLE IF NOT EXISTS silver.fat_encounters USING DELTA LOCATION 'dbfs:/user/hive/warehouse/silver.db/fat_encounters'")
df_encounters.write.format("delta").mode("append").saveAsTable("silver.fat_encounters")

# COMMAND ----------

# DBTITLE 1,pegar especificamente claims
# Explodir a coluna "entry" para acessar os dados internos
df_explodedx = df.withColumn("entry", explode(col("entry")))

# Expandir a coluna "resource" para acessar os campos internos corretamente
df_finalx = df_explodedx.select(
    col("entry.fullUrl"),
    col("entry.resource.*")  # Aqui expandimos todos os campos dentro de "resource"
)

# COMMAND ----------

# DBTITLE 1,Delta-fat_claims
# Definir o esquema esperado para "total"
total_schema = StructType([
    StructField("value", DoubleType(), True),
    StructField("currency", StringType(), True)
])

# Converter STRING para STRUCT
df_finalx = df_finalx.withColumn("total", from_json(col("total"), total_schema))

# Agora podemos extrair normalmente
df_claims = df_finalx.selectExpr(
    "id as claim_id",
    "subject.reference as patient_id",
    "total.value as claim_amount",
    "total.currency as claim_currency"
)

#df_claims.write.mode("overwrite").saveAsTable("silver.fat_claims")
df_claims.write.format("delta").mode("overwrite").save("dbfs:/user/hive/warehouse/silver.db/fat_claims")

# COMMAND ----------

# MAGIC %sql
# MAGIC --select * from silver.fat_claims

# COMMAND ----------

spark.sql("CREATE TABLE IF NOT EXISTS silver.fat_claims USING DELTA LOCATION 'dbfs:/user/hive/warehouse/silver.db/fat_claims'")
df_claims.write.format("delta").mode("append").saveAsTable("silver.fat_claims")

# COMMAND ----------

# MAGIC %md
# MAGIC # coloca no storage 

# COMMAND ----------

# DBTITLE 1,storage
#truncate
#df_final.write.mode("overwrite").parquet("dbfs:/FileStore/data/output.parquet")
#apenda incluir

#df_final.write.mode("append").parquet("dbfs:/FileStore/data/output.parquet")

# COMMAND ----------

# MAGIC %md
# MAGIC Inseri na unit catalog para começar a governança de daods

# COMMAND ----------

#from delta.tables import DeltaTable

# Tente converter o diretório existente para Delta
#DeltaTable.convertToDelta(spark, "parquet.`dbfs:/user/hive/warehouse/gold.db/fat_saude`")

# COMMAND ----------

#dbutils.fs.rm("dbfs:/user/hive/warehouse/gold.db/fat_saude", recurse=True)

# COMMAND ----------

# MAGIC %sql
# MAGIC --DROP TABLE IF EXISTS gold.fat_saude;

# COMMAND ----------

# DBTITLE 1,Delta-Origem
#df.write.mode("append").option("overwriteSchema", "true").saveAsTable("bronze.origem")
df.write.format("delta").mode("overwrite").save("dbfs:/user/hive/warehouse/bronze.db/bronze.origem")

# COMMAND ----------

# DBTITLE 1,Catalog - origem
spark.sql("CREATE TABLE IF NOT EXISTS bronze.origem USING DELTA LOCATION 'dbfs:/user/hive/warehouse/bronze.db/bronze.origem'")
df.write.format("delta").mode("append").saveAsTable("bronze.origem")

# COMMAND ----------

# DBTITLE 1,Delta- fat_saude
#df_final.write.mode("overwrite").option("overwriteSchema", "true").saveAsTable("gold.fat_saude")
#df_final.write.mode("append").option("overwriteSchema", "true").saveAsTable("gold.fat_saude")
df_final.write.format("delta").mode("append").save("dbfs:/user/hive/warehouse/gold.db/gold.fat_saude")


# COMMAND ----------

# MAGIC %sql
# MAGIC --#drop table gold.fat_saude

# COMMAND ----------

# DBTITLE 1,Catalog - fat_saude
spark.sql("CREATE TABLE IF NOT EXISTS gold.fat_saude USING DELTA LOCATION 'dbfs:/user/hive/warehouse/gold.db/gold.fat_saude'")
df_final.write.format("delta").mode("append").saveAsTable("gold.fat_saude")

# COMMAND ----------

#spark.sql("DROP TABLE IF EXISTS gold.fat_saude")

#dbutils.fs.rm("dbfs:/user/hive/warehouse/gold.db/gold.fat_saude", True)